CREATE TRIGGER AUTO_DOWNTIME_END
AFTER UPDATE
  ON DOWNTIME
FOR EACH ROW
  DECLARE
PRAGMA AUTONOMOUS_TRANSACTION;
pracownik varchar2(20);
BEGIN
  IF :new.autoend='1' THEN
    select operator into pracownik from machine where machine_id=:new.machine_id;
    -- STARA WERSJA     insert into downtime(report_time,employee_id, downknd_id, machine_id, autoend) values(:new.downtime_end, pracownik, :new.downknd_id, :new.machine_id, '2');
    insert into downtime(report_time,employee_id, downknd_id, machine_id, autoend) values(trunc(:new.downtime_end,'HH24'), pracownik, :new.downknd_id, :new.machine_id, '2');
    commit;
  END IF;
END;
/
