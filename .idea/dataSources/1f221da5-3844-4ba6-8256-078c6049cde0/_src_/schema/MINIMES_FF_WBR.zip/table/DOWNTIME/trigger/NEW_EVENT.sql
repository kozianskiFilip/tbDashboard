CREATE TRIGGER NEW_EVENT
BEFORE INSERT
  ON DOWNTIME
FOR EACH ROW
  DECLARE
cur_code number;
hr number;
--PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    --:new.prod_day := trunc(:new.report_time - interval '6' hour, 'DDD');
    --hr := to_number(to_char(:new.report_time, 'HH24'));
    --IF  hr <14 and hr >= 6 then
     -- :new.shift := 1;
   -- ELSIF hr <22 and hr >= 14 then
     --- :new.shift := 2;
    --ELSIF hr <6 or hr >= 22 then
    --  :new.shift := 3;
  --  END IF;
    
    
    
    hr := to_number(to_char(SYSDATE, 'HH24'));
    IF  hr <6 THEN
      :new.prod_day:=to_date(to_char(SYSDATE-INTERVAl '1' DAY,'yy-mm-dd')||' 00:00:00','yy-mm-dd hh24:mi:ss');
      :new.shift := 3;
    ELSIF hr <14 and hr >= 6 then
     :new.prod_day:=to_date(to_char(SYSDATE,'yy-mm-dd')||' 00:00:00','yy-mm-dd hh24:mi:ss');
      :new.shift := 1;
    ELSIF hr <22 and hr >= 14 then
      :new.prod_day:=to_date(to_char(SYSDATE,'yy-mm-dd')||' 00:00:00','yy-mm-dd hh24:mi:ss');
      :new.shift := 2;
    ELSIF hr>=22 THEN
      :new.prod_day:=to_date(to_char(SYSDATE,'yy-mm-dd')||' 00:00:00','yy-mm-dd hh24:mi:ss');
      :new.shift := 3;
    END IF;
    
    :new.report_time:=sysdate;
    IF :new.autoend is NULL THEN
      :new.autoend:=0;
    END IF;
    
IF :new.autoend!='2' THEN
  select status into cur_code  from machine where machine_id=:new.machine_id;
  IF cur_code != :new.downknd_id THEN
    UPDATE DOWNTIME SET DOWNTIME_END=SYSDATE WHERE MACHINE_ID=:NEW.MACHINE_ID and downtime_end is null;
    UPDATE MACHINE SET STATUS=:NEW.DOWNKND_ID, LAST_SCAN=SYSDATE WHERE MACHINE_ID=:NEW.MACHINE_ID;
  ELSE
    RAISE_APPLICATION_ERROR(-20101, 'To zdażenie zostalo już zarejestrowane');
    rollback;
  END IF;
END IF;
END;
/
