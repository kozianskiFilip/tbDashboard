CREATE TRIGGER UPDATE_EVENT
BEFORE UPDATE OF DOWNTIME_END
  ON DOWNTIME
FOR EACH ROW
  BEGIN
  :new.duration := (:new.downtime_end - :new.report_time)*24*60;
END;
/
