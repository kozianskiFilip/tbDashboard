CREATE TRIGGER NEW_JOB
BEFORE INSERT
  ON MAN_MACHINE
FOR EACH ROW
  DECLARE
maszyna varchar2(5) ;
user_id number(38,0) ;
BEGIN
  NULL;
  user_id := :new.employee_id;
  maszyna := :new.machine_id;
  
  UPDATE machine SET operator = user_id where machine.machine_id=maszyna;
  UPDATE man_machine SET logout = SYSDATE, self_logout=1 where machine_id=maszyna and logout is null;
  
END;
/
