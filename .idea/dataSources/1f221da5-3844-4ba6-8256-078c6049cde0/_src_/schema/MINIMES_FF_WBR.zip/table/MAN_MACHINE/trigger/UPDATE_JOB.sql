CREATE TRIGGER UPDATE_JOB
BEFORE UPDATE
  ON MAN_MACHINE
FOR EACH ROW
  declare maszyna number(38,0);
BEGIN
  IF :new.self_logout is null then
    update machine set operator = 0 where machine_id=:new.machine_id;
  end if;
END;
/
