CREATE TRIGGER TRIGGER_PREP
BEFORE INSERT
  ON PREP
FOR EACH ROW
  DECLARE
hr number;
shift_n number;
brigade varchar2(1);
schedule_date date := to_date('16-07-02 06:00:00', 'yy-mm-dd hh24:mi:ss');

BEGIN
    hr := to_number(to_char(:new.DSTAMP, 'HH24'));
    IF  hr <14 and hr >= 6 then
      shift_n:=1;
    ELSIF hr <22 and hr >= 14 then
      shift_n:=2;
    ELSIF hr <6 or hr >= 22 then
      shift_n:=3;
    END IF;

select substr(brig,shift_n,1) into brigade from schedule where day_id=MOD(trunc(:new.DSTAMP-schedule_date,0),28);
:new.BRIGADE:=brigade;

END;
/
