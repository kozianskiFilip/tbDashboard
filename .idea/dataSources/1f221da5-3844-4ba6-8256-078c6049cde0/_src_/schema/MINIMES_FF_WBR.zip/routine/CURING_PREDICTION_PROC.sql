CREATE PROCEDURE CURING_PREDICTION_PROC AS
start_date date; 
end_date date;
hr number; --godzina
pred NUMBER(8,2);
output number;

bc3_pred NUMBER(8,2);
bc3_output number;

type data_row is record(	
  PROD NUMBER, 
  WYMUSZONY NUMBER,
	OSPRZET NUMBER, 
  PRZEZBROJENIE NUMBER,
	MEMBRANY NUMBER, 
	PLANOWE NUMBER, 
	TECHNOLOGICZNE NUMBER, 
	AWARIE NUMBER, 
	CZYSZCZENIE NUMBER, 
	PM NUMBER, 
	NIEZD NUMBER,
  BRAK NUMBER);
  
  INV_OK NUMBER;
  INV_NOK NUMBER;
  
wiersz data_row;

cursor c1 is 
select SUM(DECODE(GRUPA,'Produkcja', qty, 0)) produkcja, SUM(DECODE(GRUPA,'Postój wymuszony', qty, 0))wymuszony, 
SUM(DECODE(GRUPA,'Awaria osprzętu', qty, 0)) osprzęt, 
SUM(DECODE(GRUPA,'Przezbrojenia', qty, 0))PRZEZ, 
SUM(DECODE(GRUPA,'wymiana membrany', qty, 0))MEM, 
SUM(DECODE(GRUPA,'Planowe', qty, 0))PW, 
SUM(DECODE(GRUPA,'Technologiczne', qty, 0))QT, 
SUM(DECODE(GRUPA,'Breakdown maintenance', qty, 0))CM, 
SUM(DECODE(GRUPA,'Czyszczenie form', qty, 0))Cyszcz, 
SUM(DECODE(GRUPA,'Planned maintenance', qty, 0))PM, 
SUM(DECODE(GRUPA,'Niezdefiniowane', qty, 0))niezd,
SUM(DECODE(GRUPA,'Brak opon', qty, 0))brak from 
(
select grupa,count(resrce) qty from(
select DECODE(status,'P', 'Produkcja', DECODE(last_down_code ,'23000', 'Postój wymuszony', 
'13800', 'Awaria osprzętu', 
'21800', 'Przezbrojenia', 
'22300', 'Przezbrojenia', 
'21500', 'Przezbrojenia', 
'21600', 'Przezbrojenia', 
'21100', 'Brak opon', 
'19000', 'wymiana membrany', 
'19100', 'wymiana membrany', 
'21900', 'wymiana membrany', 
'17200', 'Planowe', 
'22000', 'Technologiczne', 
'99998', 'Technologiczne', 
'18000', 'Technologiczne', 
'18700', 'Technologiczne', 
'17500E', 'Breakdown maintenance', 
'17410O', 'Czyszczenie form', 
'17410M', 'wymiana membrany', 
'17410', 'Breakdown maintenance', 
'17410K', 'Technologiczne', 
'10000', 'Breakdown maintenance', 
'14100', 'Breakdown maintenance', 
'17500M', 'Breakdown maintenance', 
'14400', 'Breakdown maintenance', 
'14000', 'Breakdown maintenance', 
'13000', 'Breakdown maintenance', 
'12000', 'Breakdown maintenance', 
'17500', 'Breakdown maintenance', 
'16100', 'Brak opon', 
'95000', 'Brak opon', 
'12800', 'Breakdown maintenance', 
'18100', 'Technologiczne', 
'10800', 'Breakdown maintenance', 
'16380', 'Brak opon', 
'99000', 'Planowe', 
'99999', 'Planowe', 
'15000', 'Planned maintenance', 
'15100', 'Planowe', 
'15300', 'Planned maintenance', 
'15200', 'Planned maintenance', 
'20000', 'Czyszczenie form', 
'20300', 'Czyszczenie form', 
'20200', 'Czyszczenie form', 
'20210', 'Czyszczenie form', 
'98000', 'Niezdefiniowane', 
'00000', 'Niezdefiniowane'
)) grupa, resrce from machines@curemes where dept='WBR')group by grupa);



BEGIN
    hr := to_number(to_char(SYSDATE, 'HH24'));
    IF  hr <14 and hr >= 6 then
      start_date:=to_date(to_char(SYSDATE,'yy-mm-dd')||' 06:00:00','yy-mm-dd hh24:mi:ss');
      end_date:=to_date(to_char(SYSDATE,'yy-mm-dd')||' 14:00:00','yy-mm-dd hh24:mi:ss');
    ELSIF hr <22 and hr >= 14 then
      start_date:=to_date(to_char(SYSDATE,'yy-mm-dd')||' 14:00:00','yy-mm-dd hh24:mi:ss');
      end_date:=to_date(to_char(SYSDATE,'yy-mm-dd')||' 22:00:00','yy-mm-dd hh24:mi:ss');
    ELSIF hr <6 then
      start_date:=to_date(to_char(SYSDATE-1,'yy-mm-dd')||' 22:00:00','yy-mm-dd hh24:mi:ss');
      end_date:=to_date(to_char(SYSDATE,'yy-mm-dd')||' 06:00:00','yy-mm-dd hh24:mi:ss');
    ELSIF hr >=22 then 
        start_date:=to_date(to_char(SYSDATE,'yy-mm-dd')||' 22:00:00','yy-mm-dd hh24:mi:ss');
        end_date:=to_date(to_char(SYSDATE+1,'yy-mm-dd')||' 06:00:00','yy-mm-dd hh24:mi:ss');
    END IF;

--OUTPUT & FORECAST CURING
  select count(barcode) into output from cure_prod_log@curemes where end_time between start_date and trunc(sysdate-interval '3' MINUTE,'mi') and resrce not like('R%');
  pred:=round((output/((trunc(sysdate-interval '3' MINUTE,'mi')-start_date)*24))*8,0);
 

--INV KONEKCJA
select  sum(case when held='N' then 1 else 0 end) OK, sum(case when held='Y' then 1 else 0 end) NOK  into INV_OK, INV_NOK
from prolag_inventory@prolag where code like 'PL-GT0%' and machine not like 'A%';
--OUTPUT & FORECAST BUILDING
select count(barcode) into bc3_output from production_log@bld left join machines@bld on machine=name where dstamp between start_date and trunc(sysdate-interval '3' MINUTE,'mi') and code like 'PL-GT%' and group_id_00='WBR';
bc3_pred:=round((bc3_output/((trunc(sysdate-interval '3' MINUTE,'mi')-start_date)*24))*8,0);

dbms_output.put_line('B: ' || bc3_pred);
open c1;
  fetch c1 into wiersz;
 insert into cur_pred values(trunc(sysdate-interval '3' MINUTE,'mi'), pred, output,wiersz.Prod,wiersz.osprzet,wiersz.membrany,wiersz.Planowe,wiersz.Technologiczne,wiersz.Awarie,wiersz.czyszczenie,wiersz.PM,wiersz.niezd,wiersz.przezbrojenie,wiersz.wymuszony,wiersz.brak,inv_ok,inv_nok,bc3_output,bc3_pred);
close c1;
  
END CURING_PREDICTION_PROC;
/
