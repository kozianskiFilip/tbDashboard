CREATE procedure register_audit( v_dept in varchar2, v_subcomitte in varchar2,
  v_area varchar2, v_auditor varchar2, v_brigade varchar2, v_shift number,
  v_q1 varchar2,v_q2 varchar2,v_q3 varchar2,v_q4 varchar2,
  v_q5 varchar2, v_q6 varchar2,v_q7 varchar2,v_q8 varchar2,v_q9 varchar2,v_q10 varchar2,v_percent number,
  v_c1 varchar2 :='', v_c2 varchar2 :='',v_c3 varchar2 :='',v_c4 varchar2 :='',v_c5 varchar2 :='',
  v_c6 varchar2 :='',v_c7 varchar2 :='',v_c8 varchar2 :='',v_c9 varchar2 :='',v_c10 varchar2 :='',g1 varchar2 :='', g2 varchar2 :='',g3 varchar2 :='' , g4 varchar2 :='') 
  IS
  type tablica is table of varchar2(400)
  index by binary_integer;
  tab tablica;
  tab2 tablica;
  iterator number(2,0) :=0;
  
  BEGIN
  
    tab(0):=v_c1;
    tab(1):=v_c2;
    tab(2):=v_c3;
    tab(3):=v_c4;
    tab(4):=v_c5;
    tab(5):=v_c6;
    tab(6):=v_c7;
    tab(7):=v_c8;
    tab(8):=v_c9;
    tab(9):=v_c10;
    
    tab2(0):=g1;
    tab2(1):=g2;
    tab2(2):=g3;
    tab2(3):=g4;
    
    --INSERT INTO A_AUDITS_RESULTS VALUES (
    insert into A_AUDITS_RESULTS(dept,subcomitte,area,auditor,brigade,shift,QA_1,QA_2,QA_3,QA_4,QA_5,QA_6,QA_7,QA_8,QA_9,QA_10,percentage)
    values (v_dept,v_subcomitte,v_area,v_auditor,v_brigade,v_shift,v_q1,v_q2,v_q3,v_q4,v_q5,v_q6,v_q7,v_q8,v_q9,v_q10,v_percent);
    
    WHILE iterator <10 LOOP 
      IF tab(iterator) is not null then
        insert into a_audits_comments values (audit_seq.currval,iterator+1,tab(iterator));
      END IF;
      iterator:=iterator+1;
    END LOOP;
    
    iterator:=0;
    WHILE iterator <4 LOOP 
      IF tab2(iterator) is not null then
        insert into a_audits_guests values (audit_seq.currval,tab2(iterator));
      END IF;
      iterator:=iterator+1;
      DBMS_OUTPUT.PUT_LINE(g1);
    END LOOP;
   DBMS_OUTPUT.PUT_LINE('xx'||g1);

  END;
/
