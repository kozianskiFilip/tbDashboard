CREATE PROCEDURE GT_CURING_COVERAGE AS 

start_date DATE := trunc(SYSDATE - INTERVAL '6' HOUR,'DDD'); 
shift_start_date DATE;
shift NUMBER;
hr NUMBER;
data_row BUILD_KANBAN%ROWTYPE;

CURSOR zapytanie(startBuilding date, shiftStart varchar2, shiftNr number, prodDay date) is 
 select curgtc, prscav, press_schedule, tot_czas, plan100,plan90,cycle_time, zazbrojone, 
        round((sysdate-last_prod_date)*24*60,2) czas,
        round((sysdate-last_down_date)*24*60,2),    
        status, 
        last_down_code,
        description,
        CASE WHEN STATUS = 'P' THEN '' ELSE  DECODE(last_down_code ,'23000', '#ffff00', 
                        '13800', '#0070c0', 
                        '21800', '#074af4', 
                        '22300', '#074af4', 
                        '21500', '#074af4', 
                        '21600', '#074af4', 
                        '21100', '#00b050', 
                        '19000', '#ffc000', 
                        '19100', '#ffc000', 
                        '21900', '#ffc000', 
                        '17200', '#dcc0e5', 
                        '22000', '#98e22f', 
                        '99998', '#d3191f', 
                        '18000', '#98e22f', 
                        '18700', '#98e22f', 
                        '17500E', '#808080', 
                        '17410O', '#07f0f4', 
                        '17410M', '#ffc000', 
                        '17410', '#808080', 
                        '17410K', '#98e22f', 
                        '10000', '#808080', 
                        '14100', '#808080', 
                        '17500M', '#808080', 
                        '14400', '#808080', 
                        '14000', '#808080', 
                        '13000', '#808080', 
                        '12000', '#808080', 
                        '17500', '#808080', 
                        '16100', '#00b050', 
                        '95000', '#00b050', 
                        '12800', '#808080', 
                        '18100', '#98e22f', 
                        '10800', '#808080', 
                        '16380', '#025b0d', 
                        '99000', '#dcc0e5', 
                        '99999', '#dcc0e5', 
                        '15000', '#dcc0e5', 
                        '15100', '#dcc0e5', 
                        '15300', '#9322b7', 
                        '15200', '#9322b7', 
                        '20000', '#07f0f4', 
                        '20300', '#07f0f4', 
                        '20200', '#07f0f4', 
                        '20210', '#07f0f4', 
                        '98000', '#ff0000', 
                        '00000', '#ff0000') END kolor,
                        nvl(plan_konf,0), nvl(Wykonanie_konf,0),nvl(maszyny_konf,''), 
                        nvl(INV_OK,0), nvl(INV_NOK,0), 
                        sum(zazbrojone) over(partition by curgtc),
                        grupy,qty_active,SYSDATE
        from
        (   --PRASY AKTUALNIE ZAZBROJONE NA DANY GT
            select curgtc, prscav, press_schedule, tot_czas, plan100,plan90,cycle_time, 1 zazbrojone
            from rfbc_cavity@sbs left join 
            (
                select distinct press_cavity,gt,sum(case when pcs>0 then time else 0 end) over(partition by press_cavity, gt) tot_czas,  sum(pcs) over(partition by press_cavity, gt)  plan100, round(sum(pcs*uptime/100) over(partition by press_cavity, gt),0) plan90, avg(case when pcs>0 then cycle_time else null end) over(partition by press_cavity, gt) cycle_time,
                listagg(case when pcs >0 or (pcs=0 and time=0) then gt else asort_action end || '/' || ct || ' ' || time || 'h, ' || pcs || '(' || round(pcs*uptime/100,0) || ')', ' </br> ') within group (order by ord) over(partition by press_cavity) press_schedule 
                from cur_schedule_by_press where prod_day=prodDay and shift=shiftNr
            ) s1 on prscav=press_cavity and curgtc=gt
            UNION ALL
             --PRASY UJETE W PLANIE ALE AKTUALNIE NIE ZAZBROJONE NA DANY GT
            select s1.gt,s1.press_cavity,press_schedule2, czas_pracy,plan100,plan90,cycle_time, 0 zazbrojone from
            (
                select gt,press_cavity
                from cur_schedule_by_press
                left join rfbc_cavity@sbs on gt=curgtc and press_cavity=prscav
                where prod_day=prodDay and shift=shift and curgtc is null and GT like 'PL-GT%' and pcs >0
            ) s1
            left join
            (
                select distinct press_cavity, gt, sum(case when pcs>0 then time else 0 end) over(partition by press_cavity, gt) czas_pracy, sum(pcs) over(partition by press_cavity, gt) plan100, round(sum(pcs*uptime/100) over(partition by press_cavity, gt),0)  plan90, avg(case when pcs>0 then cycle_time else null end) over(partition by press_cavity, gt) cycle_time,
                listagg(case when pcs >0 or (pcs=0 and time=0) then gt else asort_action end || '/' || ct || ' ' || time || 'h, ' || pcs || '(' || round(pcs*uptime/100,0) || ')', ' </br> ') within group (order by ord) over(partition by press_cavity) press_schedule2
                from cur_schedule_by_press where prod_day=prodDay and shift=shiftNr
            ) s2 on s1.press_cavity=s2.press_cavity and s1.gt=s2.gt
        ) s_global
        left join machines@curemes on resrce=prscav
        left join down_codes@curemes
        on last_down_code=down_code
        left join -- PLAN I WYKONANIE MASZYN KONF DLA DANEGO KODU
        (
            select code,sum(wykonanie) wykonanie_konf, sum(plan) plan_konf, listagg(tekst, ', ') WITHIN GROUP(order by if_active desc,machine) maszyny_konf,
            case when max(group_id)=min(group_id) then max(group_id) else min(group_id) || ' ' || max(group_id) end grupy, sum(if_active) qty_active
            from
            (
                select code, machine,group_id, sum(plan) plan, sum(wykonanie) wykonanie, active || machine || '(' || sum(plan) || ', ' || sum(wykonanie) || ')' tekst, case when active='<span style="background-color:#74f442">[X]</span>' then 1 else 0 end if_active
                from
                (
                    select schedule.code, schedule.machine, schedule.qty plan, 0 wykonanie,group_id, case when last_prod_code= schedule.code and last_prod_date>sysdate-1/24/60*30 then '<span style="background-color:#74f442">[X]</span>' else '' end active
                    from schedule@bld
                    left join machines@bld on name=schedule.machine
                    where sched_date=shiftStart and shift in (shiftNr)  and schedule.code like 'PL-GT%' 
                    and group_id_00='WBR'
                    union all
                    select code, machine, 0, qty wykonanie,group_id, case when last_prod_code = code and last_prod_date>sysdate-1/24/60*30 then '<span style="background-color:#74f442">[X]</span>' else '' end
                    from production_by_shift@bld
                    left join machines@bld on name=machine
                    where 
                    shift_start=startBuilding and production_by_shift.code like 'PL-GT%'
                    and group_id_00='WBR'
                ) group by code,group_id, machine,active
            ) group by code
        ) s1 on curgtc=code
        left join
        (
            select prolag_inventory.code, sum(case when held='N' then 1 else 0 end) INV_OK, sum(case when held='N' then 0 else 1 end) INV_NOK
            from prolag_inventory@prolag 
            where prolag_inventory.code like 'PL-GT%' group by prolag_inventory.code
        ) s2 on curgtc=s2.code
        where curgtc like 'PL-GT%' order by curgtc;

BEGIN
    hr := to_number(to_char(SYSDATE, 'HH24'));
    IF  hr <14 and hr >= 6 then
      shift_start_date:=to_date(to_char(SYSDATE,'yy-mm-dd')||' 06:00:00','yy-mm-dd hh24:mi:ss');
      shift :=1;
    ELSIF hr <22 and hr >= 14 then
      shift_start_date:=to_date(to_char(SYSDATE,'yy-mm-dd')||' 14:00:00','yy-mm-dd hh24:mi:ss');
      shift := 2;
    ELSIF hr <6 then
      shift_start_date:=to_date(to_char(SYSDATE-1,'yy-mm-dd')||' 22:00:00','yy-mm-dd hh24:mi:ss');
      shift :=3;
    ELSIF hr >=22 then 
        shift_start_date := to_date(to_char(SYSDATE,'yy-mm-dd')||' 22:00:00','yy-mm-dd hh24:mi:ss');
        shift := 3;
    END IF;
    
    delete from build_kanban;
    --zapytanie(startBuilding date, shiftStart varchar2, shiftNr number, pordDay date)
    open zapytanie(shift_start_date, to_char(SYSDATE - interval '6' hour,'yyyymmdd'), shift, start_date);
    LOOP
        EXIT WHEN zapytanie%NOTFOUND;
        fetch zapytanie into data_row;
        insert into build_kanban values data_row;
    END LOOP;
    close zapytanie;
    dbms_output.put_line(shift_start_date);
END GT_CURING_COVERAGE;
/
